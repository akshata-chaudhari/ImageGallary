package com.nikhil.downloadreadfile

import android.app.DownloadManager
import android.app.ProgressDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*


class MainActivity : AppCompatActivity() {

    var progressDialog : ProgressDialog? = null
    private lateinit var downloadManager: DownloadManager
    val FILE_URL = "http://jsonplaceholder.typicode.com/photos"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        registerReceiver(downloadReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
        progressDialog = ProgressDialog(this)
        progressDialog?.setCancelable(false)
        progressDialog?.setTitle("Loading")
        downloadFile(FILE_URL)

    }



    override fun onDestroy() {
        unregisterReceiver(downloadReceiver)
        super.onDestroy()
    }

    var downloadReference: Long = 0


    private fun downloadFile(url: String) {

        progressDialog?.show()
        downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(url))
        request.setTitle("Data Download")

        request.setDescription("Downloading Data.")
        request.setDestinationInExternalPublicDir(
            Environment.DIRECTORY_DOCUMENTS, "Data.json"
        )

        downloadReference = downloadManager.enqueue(request)

    }

    private val downloadReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(
            context: Context,
            intent: Intent
        ) {
            val referenceId =
                intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
            if (referenceId == downloadReference) {
                ReadFileTask(object : SuccessCallback{
                    override fun onSuccess(result: PhotoResponse?) {
                        setAdapter(result)
                    }

                    override fun onFail() {
                        progressDialog?.dismiss()
                    }


                }).execute()
            }

        }
    }

    class ReadFileTask(val successCallback: SuccessCallback) : AsyncTask<Void, Void, PhotoResponse>() {
        override fun doInBackground(vararg params: Void?): PhotoResponse? {
            return readFile()
        }


        override fun onPostExecute(result: PhotoResponse?) {

            if (result!=null && result.isNotEmpty()){
                successCallback.onSuccess(result)
            }else{
                successCallback.onFail()
            }
        }

        private fun readFile(): PhotoResponse?{

            val fis = FileInputStream("/storage/emulated/0/Documents/Data.json")
            val dataInputStream = DataInputStream(fis)
            val inputStream = InputStreamReader(dataInputStream)

            val byteArrayOutputStream = ByteArrayOutputStream()

            var i: Int
            try {
                i = inputStream.read()
                while (i != -1) {
                    byteArrayOutputStream.write(i)
                    i = inputStream.read()
                }
                inputStream.close()

                return Gson().fromJson(byteArrayOutputStream.toString(), PhotoResponse::class.java)

            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }

    }

    interface SuccessCallback{
        fun onSuccess(result: PhotoResponse?)
        fun onFail()

    }

    fun setAdapter(result: PhotoResponse?){
        progressDialog?.dismiss()
        if (!result.isNullOrEmpty()) {
            Log.e("size", ""+result.size)
            val linearLayoutManager = LinearLayoutManager(this)
            linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
            rvPhoto.layoutManager = linearLayoutManager

            rvPhoto.adapter = PhotoListAdapter(this, result)
        }
    }


}
